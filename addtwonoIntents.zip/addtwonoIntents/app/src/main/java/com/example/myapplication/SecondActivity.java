package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.Activity;

import android.content.Intent;

import android.os.Bundle;

import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    @Override

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        // Get the view from new_activity.xml
        setContentView(R.layout.activity_second);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String message = intent.getStringExtra("k");

        // Capture the layout's TextView and set the string as its text
        TextView textView = findViewById(R.id.reslt);
        textView.setText(message);

    }

}